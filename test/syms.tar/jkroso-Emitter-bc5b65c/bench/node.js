// node built in
module.exports = require('events').EventEmitter